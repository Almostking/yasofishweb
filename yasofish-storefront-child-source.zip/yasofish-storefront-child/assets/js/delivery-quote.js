(function () {
	'use strict';

	const form = document.querySelector('.yf-delivery-quote');
	if (!form) return;

	const method = form.querySelector('[name="method"]');
	const address = form.querySelector('.yf-delivery-address');
	const street = form.querySelector('[name="street"]');
	const region = form.querySelector('[name="region"]');
	const commune = form.querySelector('[name="commune"]');
	const city = form.querySelector('[name="city"]');
	const pickupCopy = {
		'pickup-iqq': 'Retiro en Hernán Fuenzalida 2276, Iquique. Lunes a jueves, 10:00–16:00 h; viernes a domingo, 10:00–16:30 h.',
		'pickup-hospicio': 'Retiro en Calle China 4439, sector La Pampa, Alto Hospicio. Previa coordinación, 19:00–22:30 h; días por confirmar.'
	};

	function syncDeliveryFields() {
		const isPickup = method.value.indexOf('pickup-') === 0;
		address.hidden = isPickup;
		street.required = !isPickup;
		street.disabled = isPickup;
		form.querySelector('[name="unit"]').disabled = isPickup;
		if (method.value === 'pickup-iqq') {
			region.value = 'Tarapacá';
			commune.value = 'Iquique';
			city.value = 'Iquique';
		} else if (method.value === 'pickup-hospicio') {
			region.value = 'Tarapacá';
			commune.value = 'Alto Hospicio';
			city.value = 'Alto Hospicio';
		}
	}

	method.addEventListener('change', syncDeliveryFields);
	syncDeliveryFields();

	form.addEventListener('submit', function (event) {
		event.preventDefault();
		if (!form.reportValidity()) return;

		const data = new FormData(form);
		const deliveryMethod = data.get('method');
		const lines = JSON.parse(form.dataset.items || '[]');
		const message = [
			'Hola YASOFISH, quisiera cotizar este carro antes de pagar:',
			...lines.map(function (line) { return '• ' + line; }),
			'',
			'Nombre de quien recibe: ' + data.get('name'),
			'Entrega: ' + (pickupCopy[deliveryMethod] || (deliveryMethod === 'delivery-local' ? 'Delivery Iquique / Alto Hospicio' : 'Envío a otra región')),
			'Región: ' + data.get('region'),
			'Comuna: ' + data.get('commune'),
			'Ciudad/localidad: ' + data.get('city'),
			...(pickupCopy[deliveryMethod] ? [] : [
				'Dirección: ' + data.get('street'),
				data.get('unit') ? 'Casa/departamento: ' + data.get('unit') : '',
				data.get('notes') ? 'Referencias de entrega: ' + data.get('notes') : ''
			].filter(Boolean)),
			'',
			'Por favor confirma stock, disponibilidad de la vía, costo del despacho, plazo y total final.'
		].filter(Boolean).join('\n');
		const url = 'https://wa.me/' + form.dataset.phone + '?text=' + encodeURIComponent(message);
		window.open(url, '_blank', 'noopener,noreferrer');
	});
}());
